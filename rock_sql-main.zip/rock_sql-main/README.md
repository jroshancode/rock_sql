# rock_sql



____________________________________



/*
Enter your query here.
*/

-- students => Id, Name,marks 

-- Grade => Grade, min_mark , max_Mark

-- grade lower than 8 
-- order by desc grade 

-- 8-10 => order by name



1. 2025 - 07 - 18
   https://www.kaggle.com/datasets/smayanj/e-commerce-transactions-dataset



In SQL, both subqueries and Common Table Expressions (CTEs) are mechanisms used to structure and manage complex queries, 
but they differ in their definition and usage.

Subquery
A subquery, also known as an inner query or nested query, is a SELECT statement embedded within another SQL query. 
It executes first, and its result is then used by the outer query. Subqueries can be used in various clauses, 
including SELECT, FROM, WHERE, HAVING, INSERT, UPDATE, and DELETE.

                    


# 2025 - 07 - 29 
https://www.kaggle.com/datasets/ravindrasinghrana/employeedataset

